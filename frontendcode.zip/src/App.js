import './App.css';
import BooksHomePage from './components/BooksHomePage';
import NavBar from './components/NavBar';
import BookList from './components/BookList';
import { SnackbarProvider } from 'notistack';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import AddBook from './components/AddBook';
import Signup from './components/Signup';
import Login from './components/Login';
import ExchangeRequestForm from './components/ExchangeRequestForm';
import Register from './components/Register';
import MyRequests from './components/MyRequests';
import AdminDashboard from './components/AdminDashboard';
import AdminLogin from './components/AdminLogin';
import { Navigate } from 'react-router-dom'; // Import useNavigate

function App() {

   // Check if the admin is logged in before rendering the dashboard
   const isAdminLoggedIn = localStorage.getItem('adminLoggedIn');

  return (
    <div className="App">
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route index element={<Register />} />
          <Route path="/home" element={<Home />} />
          <Route path="/addBook" element={<AddBook />} />
          <Route path="/signUp" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/booklist" element={<BookList />} />
          <Route path="/bookshomepage" element={<BooksHomePage />} />
          <Route path="/exchangerequestform" element={<ExchangeRequestForm />} />
          <Route path='/myrequests' element={ <MyRequests/>}/>
          <Route path='/admindashboard' element ={<AdminDashboard/>}/>
          <Route path="/adminlogin" element={<AdminLogin />} />
          <Route
          path="/admindashboard"
          element={isAdminLoggedIn ? <AdminDashboard /> : <Navigate to="/adminlogin" />}
        />
        </Routes>
        <SnackbarProvider />
      </BrowserRouter>
    </div>
  );
}

export default App;
