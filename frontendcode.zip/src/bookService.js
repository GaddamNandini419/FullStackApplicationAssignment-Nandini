import { myAxios } from "./helper";


 export const bookService =(book) => {

    return myAxios.get('/api/books/allbooks').then((response)=> response.json())
};