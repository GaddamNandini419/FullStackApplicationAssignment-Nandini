import React, { useState } from 'react';
import { Typography, TextField, Button, CardContent, Card, Modal, Box, FormControl, FormControlLabel, Radio, RadioGroup } from '@mui/material';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const AddBook = () => {
    const [bookId, setBookId] = useState('');
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [genre, setGenre] = useState('');
    const [status, setStatus] = useState('available'); // Default to 'available'
    const [condition, setCondition] = useState('');
    const [coverImage, setCoverImage] = useState('');

    const [modalOpen, setModalOpen] = useState(false); // Modal state
    const [modalMessage, setModalMessage] = useState(''); // Message for modal
    const [isError, setIsError] = useState(false); // To differentiate between success and error messages

    const navigate = useNavigate(); // Hook for navigation

    const handleAddBook = (e) => {
        e.preventDefault();
        const book = {
            bookId,
            title,
            author,
            genre,
            available: status === 'available', // Map the status to a boolean
            condition,
            coverImage
        };

        fetch("http://localhost:8080/api/books", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book),
        })
            .then((response) => {
                if (response.ok) {
                    setModalMessage('Book added successfully!');
                    setIsError(false);
                    // Clear input fields after successful addition
                    setBookId('');
                    setTitle('');
                    setAuthor('');
                    setGenre('');
                    setStatus('available'); // Reset to default
                    setCondition('');
                    setCoverImage('');
                } else {
                    throw new Error('Failed to add book');
                }
            })
            .catch(() => {
                setModalMessage('Failed to add book. Please try again.');
                setIsError(true);
            })
            .finally(() => {
                setModalOpen(true); // Open the modal
            });
    };

    const handleBackToHome = () => {
        setModalOpen(false); // Close the modal
        if (!isError) {
            navigate('/bookshomepage'); // Navigate to the home page
        }
    };

    return (
        <Card style={{ maxWidth: 400, marginTop: '15px', padding: '20px 5px', justifyContent: 'center', alignItems: 'center' }}>
            <CardContent>
                <Typography variant="h5" component="h2">
                    Add Book
                </Typography>
                <TextField label="BookId" fullWidth margin="normal" value={bookId} onChange={(e) => setBookId(e.target.value)} />
                <TextField label="Title" fullWidth margin="normal" value={title} onChange={(e) => setTitle(e.target.value)} />
                <TextField label="Author" fullWidth margin="normal" value={author} onChange={(e) => setAuthor(e.target.value)} />
                <TextField label="Genre" fullWidth margin="normal" value={genre} onChange={(e) => setGenre(e.target.value)} />

                {/* Radio Buttons for Availability */}
                <FormControl component="fieldset" style={{ marginTop: '10px' }}>
                    <Typography component="legend">Availability</Typography>
                    <RadioGroup
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        row
                    >
                        <FormControlLabel value="available" control={<Radio />} label="Available" />
                        <FormControlLabel value="not available" control={<Radio />} label="Not Available" />
                    </RadioGroup>
                </FormControl>

                <TextField label="Condition" fullWidth margin="normal" value={condition} onChange={(e) => setCondition(e.target.value)} />
                <TextField label="Cover Image URL" fullWidth margin="normal" value={coverImage} onChange={(e) => setCoverImage(e.target.value)} />
                <Button variant="contained" color="success" style={{ marginTop: 20 }} onClick={handleAddBook}>
                    Add
                </Button>
            </CardContent>

            {/* Modal for success and error messages */}
            <Modal
                open={modalOpen}
                onClose={handleBackToHome}
                aria-labelledby="modal-title"
                aria-describedby="modal-description"
            >
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: 300,
                        bgcolor: 'background.paper',
                        border: '2px solid #000',
                        boxShadow: 24,
                        p: 4,
                        textAlign: 'center',
                    }}
                >
                    <Typography id="modal-title" variant="h6" component="h2" color={isError ? "error" : "success"}>
                        {modalMessage}
                    </Typography>
                    <Button
                        variant="contained"
                        color={isError ? "error" : "success"}
                        onClick={handleBackToHome}
                        style={{ marginTop: '20px' }}
                    >
                        {isError ? "Close" : "Back to Home"}
                    </Button>
                </Box>
            </Modal>
        </Card>
    );
};

export default AddBook;
