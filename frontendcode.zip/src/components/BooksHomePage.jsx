import React, { useState, useEffect } from "react";
import { Container, Grid, Card, CardContent, CardMedia, Typography, Paper, Box, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import ExchangeRequestForm from "./ExchangeRequestForm";
import SearchBar from "./SearchBar";
import axios from "axios";

const BooksHomePage = () => {
    const [books, setBooks] = useState([]);
    const [selectedBook, setSelectedBook] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editForm, setEditForm] = useState({ title: "", author: "", genre: "", condition: "", available: true });
    const [searchTerm, setSearchTerm] = useState("");
    const [author, setAuthor] = useState("");
    const [genre, setGenre] = useState("");
    const [openDeleteSuccess, setOpenDeleteSuccess] = useState(false);

    useEffect(() => {
        // Fetch books from backend based on search term, author, genre, available, and status
        const fetchBooks = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/api/books/search`, {
                    params: {
                        title: searchTerm,
                        author: author,
                        genre: genre
                    }
                });
                setBooks(response.data);
            } catch (error) {
                console.error("Error fetching books:", error);
            }
        };

        fetchBooks();
    }, [searchTerm, author, genre]); // Include status as a dependency

    const handleRequestBook = (book) => {
        setSelectedBook(book); 
        setIsModalOpen(true); 
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedBook(null); 
    };

    // Handle Edit Modal Open
    const handleEditOpen = (book) => {
        setSelectedBook(book);
        setEditForm({ ...book });
        setIsEditModalOpen(true);
    };

    // Handle Edit Modal Close
    const handleCloseEditModal = () => {
        setIsEditModalOpen(false);
        setSelectedBook(null);
    };

    // Handle Edit Form Changes
    const handleEditFormChange = (e) => {
        const { name, value } = e.target;
        setEditForm((prevForm) => ({
            ...prevForm,
            [name]: value
        }));
    };

    // Update book details
    const handleUpdateBook = async () => {
        try {
            await axios.put(`http://localhost:8080/api/books/${selectedBook.bookId}`, editForm);
            setBooks(books.map((book) => (book.bookId === selectedBook.bookId ? { ...book, ...editForm } : book)));
            handleCloseEditModal();
        } catch (error) {
            console.error("Error updating book:", error);
        }
    };

    // Delete a book
    const handleDeleteBook = async (bookId) => {
        try {
            await axios.delete(`http://localhost:8080/api/books/${bookId}`);
            setBooks(books.filter((book) => book.bookId !== bookId));
            setOpenDeleteSuccess(true); // Show the success dialog
        } catch (error) {
            console.error("Error deleting book:", error);
        }
    };

    const handleCloseDeleteSuccess = () => {
        setOpenDeleteSuccess(false); // Close the success dialog
    };

    return (
        <Container sx={{ marginTop: 4 }}>
            <Typography variant="h4" gutterBottom align="center">
                Book Collection
            </Typography>

            <SearchBar setSearchTerm={setSearchTerm} setAuthor={setAuthor} setGenre={setGenre} />

            <Paper elevation={6} sx={{ padding: 4, marginTop: 2 }}>
                <Grid container spacing={3}>
                    {books.length > 0 ? (
                        books.map((book) => (
                            <Grid item xs={12} sm={6} md={4} key={book.bookId}>
                                <Card sx={{ maxWidth: 345 }}>
                                    <CardMedia
                                        component="img"
                                        alt={book.title}
                                        height="200"
                                        image={book.coverImage || "https://via.placeholder.com/200"} 
                                    />
                                    <CardContent>
                                        <Typography variant="h6" component="div">
                                            {book.title}
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <strong>Author:</strong> {book.author}
                                            <br />
                                            <strong>Genre:</strong> {book.genre}
                                            <br />
                                            <strong>Condition:</strong> {book.condition}
                                            <br />
                                            <strong>Status:</strong>{" "}
                                            {book.available ? (
                                                <Box component="span" sx={{ display: "flex", alignItems: "center", color: "green" }}>
                                                    <CheckCircleIcon fontSize="small" sx={{ marginRight: 0.5 }} /> Available
                                                </Box>
                                            ) : (
                                                <Box component="span" sx={{ display: "flex", alignItems: "center", color: "red" }}>
                                                    <CancelIcon fontSize="small" sx={{ marginRight: 0.5 }} /> Not Available
                                                </Box>
                                            )}
                                        </Typography>
                                        {book.available && (
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                fullWidth
                                                sx={{ marginTop: 1 }}
                                                onClick={() => handleRequestBook(book)}
                                            >
                                                Request
                                            </Button>
                                        )}
                                        {/* Edit Button */}
                                        <Button
                                            variant="outlined"
                                            color="primary"
                                            sx={{ marginTop: 1 }}
                                            onClick={() => handleEditOpen(book)}
                                        >
                                            <EditIcon />
                                        </Button>
                                        {/* Delete Button */}
                                        <Button
                                            variant="outlined"
                                            color="error"
                                            sx={{ marginTop: 1 }}
                                            onClick={() => handleDeleteBook(book.bookId)}
                                        >
                                            <DeleteIcon />
                                        </Button>
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))
                    ) : (
                        <Typography variant="body1" color="text.secondary" align="center">
                            No books available at the moment.
                        </Typography>
                    )}
                </Grid>
            </Paper>

            
<Dialog open={openDeleteSuccess} onClose={handleCloseDeleteSuccess}>
    <DialogTitle>Success</DialogTitle>
    <DialogContent>
        <Typography variant="body1" color="text.secondary">
            The book has been successfully deleted.
        </Typography>
    </DialogContent>
    <DialogActions>
        <Button onClick={handleCloseDeleteSuccess} color="primary">
            Close
        </Button>
    </DialogActions>
</Dialog>

            {/* Edit Book Modal */}
            <Dialog open={isEditModalOpen} onClose={handleCloseEditModal} fullWidth maxWidth="sm">
                <DialogTitle>Edit Book: {selectedBook?.title}</DialogTitle>
                <DialogContent>
                    <TextField
                        label="Title"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="title"
                        value={editForm.title}
                        onChange={handleEditFormChange}
                    />
                    <TextField
                        label="Author"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="author"
                        value={editForm.author}
                        onChange={handleEditFormChange}
                    />
                    <TextField
                        label="Genre"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="genre"
                        value={editForm.genre}
                        onChange={handleEditFormChange}
                    />
                    <TextField
                        label="Condition"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="condition"
                        value={editForm.condition}
                        onChange={handleEditFormChange}
                    />
                    <TextField
                        label="Availability"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="available"
                        type="checkbox"
                        checked={editForm.available}
                        onChange={(e) => handleEditFormChange({ target: { name: "available", value: e.target.checked } })}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseEditModal} color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={handleUpdateBook} variant="contained" color="primary">
                        Update Book
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog open={isModalOpen} onClose={handleCloseModal} fullWidth maxWidth="sm">
                <DialogTitle>Exchange Request for Book: {selectedBook?.title}</DialogTitle>
                <DialogContent>
                    <ExchangeRequestForm
                        bookTitle={selectedBook?.title}
                        onRequestSubmit={(data) => {
                            console.log("Request submitted:", data);
                            handleCloseModal();
                        }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal} color="secondary">
                        Cancel
                    </Button>
                </DialogActions>
            </Dialog>
        </Container>
    );
};

export default BooksHomePage;
