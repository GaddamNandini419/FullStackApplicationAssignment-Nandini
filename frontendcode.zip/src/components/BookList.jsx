import React, { useState } from 'react';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import booksData from '../booksData';

const BookList = ({ addToCart }) => {
    const [modalOpen, setModalOpen] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalSeverity, setModalSeverity] = useState('success');

    const handleAddToCart = (book) => {
        if (book.available) {
            addToCart(book);
            setModalMessage(`${book.title} has been added to your cart.`);
            setModalSeverity('success');
        } else {
            setModalMessage(`${book.title} is currently unavailable.`);
            setModalSeverity('warning');
        }
        setModalOpen(true);
    };

    const handleModalClose = () => {
        setModalOpen(false);
    };

    return (
        <div style={{ padding: '20px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around' }}>
            {booksData.map((book) => (
                <Card key={book.id} sx={{ width: 250, margin: '10px', position: 'relative' }}>
                    <CardMedia
                        component="img"
                        alt={book.title}
                        height="140"
                        image={book.coverImage}
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            {book.title}
                        </Typography>
                        <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                            Author: {book.author} <br />
                            Genre: {book.genre} <br />
                            Status: {book.available ? (
                                <span style={{ color: 'green', display: 'flex', alignItems: 'center' }}>
                                    <CheckCircleIcon fontSize="small" /> Available
                                </span>
                            ) : (
                                <span style={{ color: 'red', display: 'flex', alignItems: 'center' }}>
                                    <CancelIcon fontSize="small" /> Not Available
                                </span>
                            )}
                        </Typography>
                    </CardContent>
                    <CardActions>
                        <Button size="small">View More</Button>
                        <Button 
                            size="small" 
                            onClick={() => handleAddToCart(book)}
                        >
                            Add to Cart
                        </Button>
                    </CardActions>
                </Card>
            ))}

            {/* Modal for Notifications */}
            <Modal
                open={modalOpen}
                onClose={handleModalClose}
                aria-labelledby="notification-modal-title"
                aria-describedby="notification-modal-description"
            >
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        bgcolor: 'black',
                        color: 'white',
                        borderRadius: 2,
                        p: 4,
                        minWidth: 300,
                        textAlign: 'center'
                    }}
                >
                    <Typography id="notification-modal-title" variant="h6" component="h2">
                        {modalSeverity === 'success' ? 'Success' : 'Alert'}
                    </Typography>
                    <Typography id="notification-modal-description" sx={{ mt: 2 }}>
                        {modalMessage}
                    </Typography>
                    <Button 
                        onClick={handleModalClose} 
                        variant="contained" 
                        sx={{ mt: 3, bgcolor: 'white', color: 'black' }}
                    >
                        Close
                    </Button>
                </Box>
            </Modal>
        </div>
    );
};

export default BookList;
