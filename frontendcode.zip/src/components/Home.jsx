
import React from 'react';
import Typography from '@mui/material/Typography';

const Home = () => {

    return (
    <div>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Home
        </Typography>
        <div>
           <Typography>
                 Welcome to Book Exchange
            </Typography>
        </div>
     </div>
    );
};

export default Home;
