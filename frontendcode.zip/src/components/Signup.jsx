
import React from 'react';
import Typography from '@mui/material/Typography';

const Signup = () => {

    return(
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          SignUp
        </Typography>
    );
};

export default Signup;
