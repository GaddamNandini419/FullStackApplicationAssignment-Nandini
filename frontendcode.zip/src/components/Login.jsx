import React, { useState } from 'react';
import { TextField, Button, Card, CardContent, Typography } from '@mui/material';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        const loginData = {
            email,
            password,
        };
        console.log('Logging in:', loginData);
        // Add fetch or Axios POST request to login API endpoint here
    };

    return (
        <Card
            style={{
                maxWidth: 400,
                margin: '20px auto',
                padding: '20px',
                textAlign: 'center',
            }}
        >
            <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                    Login
                </Typography>
                <TextField
                    label="Email"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <TextField
                    label="Password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={handleLogin}
                    style={{ marginTop: '20px' }}
                >
                    Login
                </Button>
            </CardContent>
        </Card>
    );
};

export default Login;
