import React, { useState } from 'react';
import { TextField, Button, Card, CardContent, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    // Simulating an admin login check
    const handleLogin = () => {
        if (username === 'admin' && password === 'admin123') {
            // Save login state to localStorage
            localStorage.setItem('adminLoggedIn', true);
            navigate('/admindashboard'); // Redirect to Admin Dashboard after login
        } else {
            setError('Invalid credentials. Please try again.');
        }
    };

    return (
        <Card style={{ maxWidth: 400, margin: '20px auto', padding: '20px', textAlign: 'center' }}>
            <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                    Admin Login
                </Typography>
                <TextField
                    label="Username"
                    fullWidth
                    margin="normal"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                <TextField
                    label="Password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                {error && <Typography color="error">{error}</Typography>}
                <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={handleLogin}
                    style={{ marginTop: '20px' }}
                >
                    Login
                </Button>
            </CardContent>
        </Card>
    );
};

export default AdminLogin;
