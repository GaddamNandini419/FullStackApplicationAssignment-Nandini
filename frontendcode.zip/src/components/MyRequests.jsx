import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent, Typography, Button, CircularProgress, Box } from '@mui/material';

const MyRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch all exchange requests when the component mounts
  useEffect(() => {
    axios.get('http://localhost:8080/exchange-requests/requested-books')
      .then((response) => {
        console.log("Fetched Data:", response.data); // Log the response to check its structure
        setRequests(response.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching data:", err); // Log error for debugging
        setError('Error fetching exchange requests');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div style={{ textAlign: 'center', marginTop: '20px' }}><CircularProgress size={50} color="primary" /></div>;
  }

  if (error) {
    return <div style={{ textAlign: 'center', marginTop: '20px' }}><Typography color="error">{error}</Typography></div>;
  }

  return (
    <div style={{ padding: '30px'}}>
      <Typography variant="h4" gutterBottom align="center" style={{ color: '#3f51b5' }}>
        Requested Exchange Books
      </Typography>
      
      {/* If no exchange requests */}
      {requests.length === 0 ? (
        <Typography align="center" style={{ fontSize: '18px', color: '#555' }}>No exchange requests found.</Typography>
      ) : (
        // Displaying the items row-wise with multiple cards per row
        <Box display="flex" flexDirection="column" alignItems="center">
          {requests.map((request, index) => (
            <Box
              key={request.id}
              sx={{
                display: 'flex',
                flexDirection: 'row',
                flexWrap: 'wrap',
                justifyContent: 'center',
                width: '100%',
                gap: 2,
                marginBottom: '20px',
              }}
            >
              <Card 
                sx={{
                  borderRadius: '10px',
                  boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)', 
                  backgroundColor: '#ffffff',
                  width: '300px',
                  transition: 'transform 0.3s',
                  '&:hover': { transform: 'scale(1.05)' },
                }}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom sx={{ fontSize: '18px', fontWeight: '600' }}>
                    {`Book ID: ${request.bookId}`}
                  </Typography>
                  <Typography variant="body1" gutterBottom sx={{ fontSize: '16px', color: '#333' }}>
                    <strong>Requester Name:</strong> {request.requesterName}
                  </Typography>
                  <Typography variant="body1" gutterBottom sx={{ fontSize: '16px', color: '#333' }}>
                    <strong>Delivery Method:</strong> {request.deliveryMethod}
                  </Typography>
                  <Typography variant="body1" gutterBottom sx={{ fontSize: '16px', color: '#333' }}>
                    <strong>Exchange Duration:</strong> {request.exchangeDuration}
                  </Typography>
                  <Typography variant="body1" gutterBottom sx={{ fontSize: '16px', color: '#333' }}>
                    <strong>Status:</strong> {request.status}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" sx={{ fontSize: '14px', marginBottom: '15px' }}>
                    <strong>Message:</strong> {request.message}
                  </Typography>

                  <Box sx={{ textAlign: 'center' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      sx={{ width: '80%', padding: '10px 0', fontSize: '14px' }}
                    >
                      Change Status
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Box>
          ))}
        </Box>
      )}
    </div>
  );
};

export default MyRequests;
