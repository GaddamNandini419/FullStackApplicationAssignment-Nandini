import React, { useState } from 'react';
import { TextField, Button, Card, CardContent, Typography, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // updated import

const Register = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('USER'); // Default role
    const [openModal, setOpenModal] = useState(false); // For modal visibility

    const navigate = useNavigate(); // updated hook

    const handleRegister = async () => {
        const registerData = {
            username,
            email,
            password,
            active: true, // Default value for new registrations
            role,
        };

        try {
            const response = await axios.post('http://localhost:8080/api/users/register', registerData);
            console.log('Registration successful:', response.data);
            setOpenModal(true); // Open modal on successful registration
        } catch (error) {
            console.error('Error registering user:', error.response ? error.response.data : error.message);
            alert('Registration failed. Please try again.');
        }
    };

    const handleCloseModal = () => {
        setOpenModal(false); // Close modal
        navigate('/bookshomepage'); // Redirect to books homepage
    };

    return (
        <Card
            style={{
                maxWidth: 400,
                margin: '20px auto',
                padding: '20px',
                textAlign: 'center',
            }}
        >
            <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                    Register
                </Typography>
                <TextField
                    label="Username"
                    fullWidth
                    margin="normal"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                <TextField
                    label="Email"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <TextField
                    label="Password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <TextField
                    label="Role"
                    select
                    fullWidth
                    margin="normal"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    helperText="Please select your role"
                >
                    <option value="USER">User</option>
                    <option value="ADMIN">Admin</option>
                </TextField>
                <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={handleRegister}
                    style={{ marginTop: '20px' }}
                >
                    Register
                </Button>
            </CardContent>

            {/* Success Registration Modal */}
            <Dialog open={openModal} onClose={handleCloseModal}>
                <DialogTitle>Registration Successful</DialogTitle>
                <DialogContent>
                    <Typography variant="body1">You have been successfully registered!</Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal} color="primary">
                        OK
                    </Button>
                </DialogActions>
            </Dialog>
        </Card>
    );
};

export default Register;
