import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Typography, Box, Container, Grid } from '@mui/material';

const ExchangeRequestForm = () => {
  const [bookId, setBookId] = useState('');
  const [requesterName, setRequesterName] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState('');
  const [exchangeDuration, setExchangeDuration] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const newRequest = {
      bookId,
      requesterName,
      deliveryMethod,
      exchangeDuration,
      message,
    };

    axios.post('http://localhost:8080/exchange-requests', newRequest)
      .then((response) => {
        alert('Exchange Request Submitted');
        // Redirect to the My Requests page after submission
        navigate('/myrequests');
      })
      .catch((error) => {
        alert('Error submitting request');
      });
  };

  return (
    <Container maxWidth="sm" sx={{ padding: '20px' }}>
      <Typography variant="h4" align="center" gutterBottom>
        Exchange Request Form
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              label="Book ID"
              variant="outlined"
              fullWidth
              value={bookId}
              onChange={(e) => setBookId(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Requester Name"
              variant="outlined"
              fullWidth
              value={requesterName}
              onChange={(e) => setRequesterName(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Delivery Method"
              variant="outlined"
              fullWidth
              value={deliveryMethod}
              onChange={(e) => setDeliveryMethod(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Exchange Duration"
              variant="outlined"
              fullWidth
              value={exchangeDuration}
              onChange={(e) => setExchangeDuration(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Message"
              variant="outlined"
              fullWidth
              multiline
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <Box textAlign="center">
              <Button variant="contained" color="primary" type="submit" fullWidth>
                Submit Request
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
};

export default ExchangeRequestForm;
