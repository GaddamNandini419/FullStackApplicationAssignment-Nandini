import React, { useState, useEffect } from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { Link } from 'react-router-dom';
import axios from 'axios'; // For API calls (if needed)

const NavBar = () => {
  const [role, setRole] = useState(''); // State to store the user role
  const [loading, setLoading] = useState(true); // Loading state

  useEffect(() => {
    // Fetch user role or check authentication status (e.g., JWT token or API call)
    const fetchUserRole = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/users/current'); // Assuming an endpoint for fetching current user
        setRole(response.data.role); // Assuming the response has a `role` field
        setLoading(false);
      } catch (error) {
        console.error('Error fetching user role:', error);
        setLoading(false);
      }
    };

    fetchUserRole();
  }, []);

  return (
    <AppBar position="static">
      <Toolbar>
        <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ mr: 2 }}
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Book Exchange
        </Typography>
        <Button color="inherit" component={Link} to="/addbook">
          Add Book
        </Button>
        <Button color="inherit" component={Link} to="/register">
          Register
        </Button>
        <Button color="inherit" component={Link} to="/exchangerequestform">
          Request Exchange
        </Button>
        <Button color="inherit" component={Link} to="/myrequests">
          My Requests
        </Button>
        {!loading && role === 'ADMIN' && (  // Only show if the role is 'ADMIN'
          <Button color="inherit" component={Link} to="/admindashboard">
            Admin Dashboard
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
