// src/components/BookList.js
import React from "react";

const BookLists = ({ books }) => {
  return (
    <div className="book-list">
      {books.length === 0 ? (
        <p>No books found.</p>
      ) : (
        books.map((book) => (
          <div key={book.bookId} className="book-item">
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <p>{book.genre}</p>
            <p>{book.status}</p>
            <img src={book.coverImage} alt={`${book.title} cover`} />
          </div>
        ))
      )}
    </div>
  );
};

export default BookLists;
