// src/components/SearchBar.js
import React, { useState } from "react";
import { TextField, Button, Box, Grid } from "@mui/material";

const SearchBar = ({ setSearchTerm, setAuthor, setGenre }) => {
    const [title, setTitle] = useState("");
    const [author, setAuthorInput] = useState("");
    const [genre, setGenreInput] = useState("");
    

    const handleSearch = () => {
        setSearchTerm(title); // Update title search term
        setAuthor(author); // Update author search term
        setGenre(genre); // Update genre search term
       
    };

    return (
        <Box display="flex" justifyContent="center" sx={{ marginBottom: 4 }}>
            <Grid container spacing={2}>
                <Grid item xs={4}>
                    <TextField
                        label="Search by Title"
                        variant="outlined"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        fullWidth
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextField
                        label="Search by Author"
                        variant="outlined"
                        value={author}
                        onChange={(e) => setAuthorInput(e.target.value)}
                        fullWidth
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextField
                        label="Search by Genre"
                        variant="outlined"
                        value={genre}
                        onChange={(e) => setGenreInput(e.target.value)}
                        fullWidth
                    />
                </Grid>
                
            </Grid>
            <Button variant="contained" onClick={handleSearch} sx={{ marginBottom: 1, marginLeft: 5 } }>
                Search
            </Button>
        </Box>
    );
};

export default SearchBar;
