import React, { useState, useEffect } from "react";
import ExchangeRequestForm from "./ExchangeRequestForm"; // Import your form

const BookExchangePage = () => {
    const [defaultData, setDefaultData] = useState(null);

    // Simulate an API call to fetch default data
    useEffect(() => {
        // You can replace this with your actual API call
        const fetchDefaultData = async () => {
            const data = {
                deliveryMethod: "Courier",
                exchangeDuration: "2 weeks",
                message: "Looking forward to the exchange.",
            };
            setDefaultData(data);
        };

        fetchDefaultData();
    }, []);

    // Render the form with default data once it's fetched
    return (
        <div>
            {defaultData ? (
                <ExchangeRequestForm
                    bookTitle="Sample Book Title"
                    defaultData={defaultData}
                    onRequestSubmit={(data) => console.log(data)}
                />
            ) : (
                <div>Loading...</div>
            )}
        </div>
    );
};

export default BookExchangePage;
