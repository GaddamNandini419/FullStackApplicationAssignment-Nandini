import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';

const AdminDashboard = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch all exchange requests
  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await axios.get('http://localhost:8080/exchange-requests/requested-books'); // Replace with your API endpoint
        setRequests(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching requests:', error);
        setLoading(false);
      }
    };

    fetchRequests();
  }, []);

  const approveRequest = async (requestId) => {
    const url = `http://localhost:8080/exchange-requests/${requestId}/approve`; // Use requestId
    console.log('Approving request with URL:', url); // Log the URL to verify
  
    try {
      const response = await axios.put(url);
      console.log('Approve request response:', response); // Log the response
      alert('Request Approved!');
      setRequests((prevRequests) =>
        prevRequests.map((request) =>
          request.id === requestId ? { ...request, status: 'Approved' } : request
        )
      );
    } catch (error) {
      console.error('Error approving request:', error); // Log the error
      alert('Error approving request');
    }
  };
  
  

  if (loading) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <div>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard - Manage Exchange Requests
      </Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Book ID</TableCell>
            <TableCell>Requester Name</TableCell>
            <TableCell>Delivery Method</TableCell>
            <TableCell>Exchange Duration</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {requests.map((request) => (
            <TableRow key={request.id}>
              <TableCell>{request.bookId}</TableCell>
              <TableCell>{request.requesterName}</TableCell>
              <TableCell>{request.deliveryMethod}</TableCell>
              <TableCell>{request.exchangeDuration}</TableCell>
              <TableCell>{request.status}</TableCell>
              <TableCell>
                {request.status !== 'Approved' && (
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => approveRequest(request.id)}
                  >
                    Approve
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default AdminDashboard;
